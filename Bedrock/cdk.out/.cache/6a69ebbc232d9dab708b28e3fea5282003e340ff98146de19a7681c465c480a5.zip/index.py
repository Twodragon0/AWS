# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0.
#

'''
AWS Lambda hosted Slack ChatBot integration to Amazon Bedrock Knowledge Base. 
Expects Slack Bot Slash Command given by the SLACK_SLASH_COMMAND param and presents 
a user query to the Bedrock Knowledge Base described by the KNOWLEDGEBASE_ID parameter.

The user query is used in a Bedrock KB ReteriveandGenerate API call and the KB 
response is presented to the user in Slack.

Slack integration based on SlackBolt library and examples given at:
https://github.com/slackapi/bolt-python/blob/main/examples/aws_lambda/lazy_aws_lambda.py
 '''
 
__version__ = "0.0.1"
__status__ = "Development"
__copyright__ = "Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved."
__author__ = "Dean Colcott <https://www.linkedin.com/in/deancolcott/>"

import os
import json
import boto3
import logging
from slack_bolt import App
from slack_bolt.adapter.aws_lambda import SlackRequestHandler
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

# Get params from SSM
def get_parameter(parameter_name):
    ssm = boto3.client('ssm')
    try:
        response = ssm.get_parameter(
            Name=parameter_name,
            WithDecryption=True
        )
        # Parse the JSON string from the parameter
        parameter_value = response['Parameter']['Value']
        
        #Remove the JSON structure and extract just the value
        try:
            json_value = json.loads(parameter_value)
            # Get the first value from the dictionary
            value = next(iter(json_value.values()))
            return value
        except (json.JSONDecodeError, StopIteration):
            # If parsing fails or dictionary is empty, return the raw value
            return parameter_value
            
    except Exception as e:
        print(f"Error getting parameter {parameter_name}: {str(e)}")
        raise e

# Get parameter names from environment variables
bot_token_parameter = os.environ['SLACK_BOT_TOKEN_PARAMETER']
signing_secret_parameter = os.environ['SLACK_SIGNING_SECRET_PARAMETER']

# Retrieve the parameters
bot_token = get_parameter(bot_token_parameter)
signing_secret = get_parameter(signing_secret_parameter)

# Initialize Slack app
app = App(
    process_before_response=True,
    token=bot_token,
    signing_secret=signing_secret
)

# Get the expected slack and AWS account params to local vars. 
SLACK_SLASH_COMMAND = os.environ['SLACK_SLASH_COMMAND']
KNOWLEDGEBASE_ID = os.environ['KNOWLEDGEBASE_ID'] 
RAG_MODEL_ID = os.environ['RAG_MODEL_ID'] 
AWS_REGION = os.environ['AWS_REGION']
GUARD_RAIL_ID = os.environ['GUARD_RAIL_ID']
GUARD_VERSION = os.environ['GUARD_RAIL_VERSION']

print(f'GR_ID,{GUARD_RAIL_ID}')
print(f'GR_V, {GUARD_VERSION}')

# Initialize Bedrock client
bedrock_client = boto3.client(
    service_name='bedrock-runtime',
    region_name=os.environ.get('AWS_REGION', 'us-east-1')
)

@app.middleware
def log_request(logger, body, next):
  '''
    SlackBolt library logging. 
  '''
  logger.debug(body)
  return next()

def respond_to_slack_within_3_seconds(body, ack):
  '''
    Slack Bot Slash Command requires an Ack response within 3 seconds or it 
    messages an operation timeout error to the user in the chat thread. 

    The SlackBolt library provides a Async Ack function then re-invokes this Lambda 
    to LazyLoad the process_command_request command that calls the Bedrock KB ReteriveandGenerate API.

    This function is called initially to acknowledge the Slack Slash command within 3 secs. 
  '''
  try:
    user_query = body["text"]
    logging.info(f"${SLACK_SLASH_COMMAND} - Acknowledging command: {SLACK_SLASH_COMMAND} - User Query: {user_query}\n")
    ack(f"\n${SLACK_SLASH_COMMAND} - Processing Request: {user_query}")

  except Exception as err:
    print(f"${SLACK_SLASH_COMMAND} - Error: {err}")
    respond(f"${SLACK_SLASH_COMMAND} - Sorry an error occurred. Please try again later. Error: {err}")

def process_command_request(respond, body):
  '''
    Receive the Slack Slash Command user query and proxy the query to Bedrock Knowledge base ReteriveandGenerate API 
    and return the response to Slack to be presented in the users chat thread. 
  '''
  try:
    # Get the user query
    user_query = body["text"]
    logging.info(f"${SLACK_SLASH_COMMAND} - Responding to command: {SLACK_SLASH_COMMAND} - User Query: {user_query}")

    kb_response = get_bedrock_knowledgebase_response(user_query)
    response_text = kb_response["output"]["text"]
    respond(f"\n${SLACK_SLASH_COMMAND} - Response: {response_text}\n")
  
  except Exception as err:
    print(f"${SLACK_SLASH_COMMAND} - Error: {err}")
    respond(f"${SLACK_SLASH_COMMAND} - Sorry an error occurred. Please try again later. Error: {err}")

def get_bedrock_knowledgebase_response(user_query):
  '''
    Get and return the Bedrock Knowledge Base ReteriveAndGenerate response.
    Do all init tasks here instead of globally as initial invocation of this lambda
    provides Slack required ack in 3 sec. It doesn't trigger any bedrock functions and is 
    time sensitive. 
  '''

  #Create the RetrieveAndGenerateCommand input with the user query.
  input =  { 
      "text": user_query
    }

  config = {
    "type" : "KNOWLEDGE_BASE",
    "knowledgeBaseConfiguration": {
        "generationConfiguration": {
            "guardrailConfiguration": {
                "guardrailId": GUARD_RAIL_ID,
                "guardrailVersion": GUARD_VERSION
            },
        },
        "knowledgeBaseId": KNOWLEDGEBASE_ID,
        "modelArn": RAG_MODEL_ID
   }
  }

  response = bedrock_client.retrieve_and_generate(
    input=input, retrieveAndGenerateConfiguration=config
  )
  logging.info(f"Bedrock Knowledge Base Response: {response}")
  return response

# Init the Slack Slash '/' command handler.
app.command(SLACK_SLASH_COMMAND)(ack=respond_to_slack_within_3_seconds, lazy=[process_command_request])

# ─── Message Shortcut 처리 핸들러 추가 ─────────────────────────────────────────────
@app.shortcut("aws-chatbot")
def handle_message_shortcut(ack, shortcut, client, logger):
    try:
        # 1) Slack에 3초 내 ACK
        ack()

        # 2) 선택된 메시지 텍스트 추출 및 이벤트 로그 파싱
        message_text = shortcut["message"]["text"]
        logger.info(f"Shortcut triggered – message: {message_text}")

        # 이벤트 로그 파싱 시도
        try:
            # JSON 형식의 로그인 경우 파싱
            if message_text.strip().startswith('{'):
                log_data = json.loads(message_text)
                # 로그 레벨, 서비스, 메시지 등 추출
                log_level = log_data.get('level', 'INFO')
                service = log_data.get('service', 'unknown')
                log_message = log_data.get('message', '')
                timestamp = log_data.get('timestamp', '')
                
                # 로그 분석을 위한 컨텍스트 생성
                log_context = f"""
로그 레벨: {log_level}
서비스: {service}
타임스탬프: {timestamp}
메시지: {log_message}
                """
            else:
                log_context = message_text
        except json.JSONDecodeError:
            log_context = message_text

        # 3) Bedrock 모델 호출
        try:
            # Claude 모델용 요청 형식
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 1000,
                "temperature": 0.7,
                "messages": [
                    {
                        "role": "user",
                        "content": f"""다음 이벤트를 DevSecOps 관점에서 분석하고 한국어로 평가해주세요.
응답은 Slack 메시지 형식으로 작성해주세요. 이모티콘, 코드 블록, 링크, 목록을 적절히 활용해주세요.

{log_context}

다음 항목들을 포함하여 분석해주세요:

1. 로그 분석 및 보안 자동화:
   - 로그 패턴 및 이상 징후 식별
   - 자동화된 로그 분석 파이프라인 구축 방안
   - 이벤트 모니터링 규칙 자동화 제안
   - 로그 기반 보안 자동화 워크플로우 설계

2. 지속적인 모니터링:
   - 로그 기반 실시간 위협 탐지 전략
   - 이벤트 대시보드 구성 최적화
   - 로그 메트릭 및 알림 설정
   - 로그 상관 관계 분석 및 시각화

3. 인시던트 대응:
   - 로그 기반 인시던트 대응 플레이북
   - 로그 패턴 기반 자동 대응 규칙
   - 인시던트 우선순위화 및 분류
   - 로그 기반 사후 분석 및 개선

4. 보안 최적화:
   - 이벤트 보안 모니터링 설정
   - 로그 수집 및 분석 파이프라인 보안
   - 로그 데이터 보호 및 접근 제어
   - 보안 로그 통합 및 분석

분석 시 다음 DevSecOps 원칙을 고려해주세요:
- 로그 기반 보안 자동화
- 실시간 로그 모니터링
- 로그 기반 인시던트 대응
- 로그 데이터 보안
- 지속적인 로그 분석 및 개선

응답 형식:
1. 이모티콘을 사용하여 각 섹션을 구분
2. 코드 블록을 사용하여 로그 패턴이나 설정 예시를 표시
3. 링크를 사용하여 관련 문서나 리소스를 참조
4. 목록을 사용하여 권장사항을 구조화
5. 중요 정보는 *굵게* 표시
6. 각 섹션은 명확하게 구분"""
                    }
                ]
            }

            response = bedrock_client.invoke_model(
                modelId=os.environ["RAG_MODEL_ID"],
                body=json.dumps(request_body)
            )
            
            # 응답 파싱
            response_body = json.loads(response.get("body").read())
            answer = response_body.get("content", [{}])[0].get("text", "응답 생성에 실패했습니다.")
            
        except Exception as e:
            logger.error(f"Bedrock 호출 오류: {e}")
            answer = f"Bedrock 모델 호출 중 오류가 발생했습니다: {str(e)}"

        # 4) Thread 메시지 전송
        try:
            # 먼저 메시지를 전송하고 thread_ts를 얻음
            response = client.chat_postMessage(
                channel=shortcut["channel"]["id"],
                thread_ts=shortcut["message"]["ts"],  # 원본 메시지의 타임스탬프
                text=(
                    f":bar_chart: *이벤트 로그 분석 결과*\n\n"
                    f":page_facing_up: *원본 로그*\n```{message_text}```\n\n"
                    f":mag: *분석 결과*\n{answer}\n\n"
                    f":information_source: *참고*\n"
                    f"- 이 분석은 DevSecOps 관점에서 수행되었습니다.\n"
                    f"- 자세한 내용은 각 섹션의 링크를 참조하세요.\n"
                    f"- 추가 질문이 있으시면 언제든지 문의해주세요."
                )
            )
            logger.info(f"Thread 메시지 전송 성공: {response}")
        except SlackApiError as e:
            logger.error(f"Slack 메시지 전송 오류: {e}")
            return {
                "statusCode": 200,
                "body": ""
            }
        
    except Exception as e:
        logger.error(f"Shortcut 처리 오류: {str(e)}")
        return {
            "statusCode": 200,
            "body": ""
        }

# ────────────────────────────────────────────────────────────────────────────────

# Init the Slack Bolt logger and log handlers. 
SlackRequestHandler.clear_all_log_handlers()
logging.basicConfig(format="%(asctime)s %(message)s", level=logging.DEBUG)

# Lambda handler method.
def handler(event, context):
    try:
        logger.info(f"Received event: {json.dumps(event)}")
        
        # Initialize SlackRequestHandler
        slack_handler = SlackRequestHandler(app=app)
        
        # Process the event
        response = slack_handler.handle(event, context)
        
        logger.info(f"Handler response: {json.dumps(response)}")
        
        # 응답이 없는 경우 기본 응답 반환
        if not response:
            return {
                "statusCode": 200,
                "body": ""
            }
            
        return response
        
    except Exception as e:
        logger.error(f"Handler error: {str(e)}")
        logger.error(f"Event: {json.dumps(event)}")
        return {
            "statusCode": 200,  # Slack은 항상 200 응답을 기대함
            "body": ""
        }

# 멘션 이벤트 핸들러 추가
@app.event("app_mention")
def handle_mentions(event, say, logger):
    try:
        logger.info(f"Received mention event: {json.dumps(event)}")
        
        # 멘션된 메시지 텍스트 추출
        message_text = event.get("text", "")
        # 멘션 부분 제거
        bot_user_id = app.client.auth_test()['user_id']
        message_text = message_text.replace(f"<@{bot_user_id}>", "").strip()
        
        logger.info(f"Processed message text: {message_text}")
        
        # 보안 업데이트 관련 키워드 확인
        security_keywords = ["보안 업데이트", "취약점", "CVE", "패치", "업데이트 권고"]
        if any(keyword in message_text for keyword in security_keywords):
            logger.info("Security update detected, analyzing...")
            # 보안 업데이트 분석 요청
            analyze_security_update(message_text, say, logger)
        else:
            logger.info("General mention detected, processing...")
            # 일반적인 멘션 처리
            process_mention(message_text, say, logger)
            
    except Exception as e:
        logger.error(f"Error handling mention: {str(e)}")
        logger.error(f"Event data: {json.dumps(event)}")
        say("죄송합니다. 처리 중 오류가 발생했습니다. 다시 시도해주세요.")

def analyze_security_update(message_text, say, logger):
    try:
        logger.info("Starting security update analysis...")
        
        # Bedrock 모델 호출
        request_body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1000,
            "temperature": 0.7,
            "messages": [
                {
                    "role": "user",
                    "content": f"""다음 보안 업데이트 공지를 DevSecOps 관점에서 분석하고 한국어로 평가해주세요.
응답은 Slack 메시지 형식으로 작성해주세요. 이모티콘, 코드 블록, 링크, 목록을 적절히 활용해주세요.

{message_text}

다음 항목들을 포함하여 분석해주세요:

1. 취약점 분석 :warning::
   - 취약점 유형 및 심각도
   - 영향받는 시스템 및 서비스
   - 잠재적 위험 및 영향도
   - CVE 정보 분석

2. 대응 방안 :gear::
   - 패치 적용 우선순위
   - 임시 조치 방안
   - 업데이트 절차
   - 롤백 계획

3. 모니터링 및 자동화 :chart_with_upwards_trend::
   - 취약점 스캔 자동화
   - 패치 적용 모니터링
   - 영향도 분석 자동화
   - 알림 설정

4. 보안 최적화 :shield::
   - 취약점 예방 방안
   - 보안 강화 조치
   - 자동화된 보안 검증
   - 지속적인 모니터링

분석 시 다음 원칙을 고려해주세요:
- 빠른 대응 및 자동화
- 위험 기반 우선순위화
- 지속적인 모니터링
- 사후 분석 및 개선"""
                }
            ]
        }

        logger.info("Calling Bedrock model...")
        response = bedrock_client.invoke_model(
            modelId=os.environ["RAG_MODEL_ID"],
            body=json.dumps(request_body)
        )
        
        # 응답 파싱
        response_body = json.loads(response.get("body").read())
        answer = response_body.get("content", [{}])[0].get("text", "응답 생성에 실패했습니다.")
        
        logger.info("Sending analysis results...")
        # 분석 결과 전송
        say(
            f":shield: *보안 업데이트 분석 결과*\n\n"
            f":page_facing_up: *원본 공지*\n```{message_text}```\n\n"
            f":mag: *분석 결과*\n{answer}\n\n"
            f":information_source: *참고*\n"
            f"- 이 분석은 DevSecOps 관점에서 수행되었습니다.\n"
            f"- 자세한 내용은 각 섹션의 링크를 참조하세요.\n"
            f"- 추가 질문이 있으시면 언제든지 문의해주세요."
        )
        
    except Exception as e:
        logger.error(f"Error analyzing security update: {str(e)}")
        logger.error(f"Message text: {message_text}")
        say("보안 업데이트 분석 중 오류가 발생했습니다. 다시 시도해주세요.")

def process_mention(message_text, say, logger):
    try:
        logger.info("Processing general mention...")
        # 일반적인 멘션 처리 로직
        say(
            f":wave: 안녕하세요! 보안 업데이트나 취약점 관련 문의는 언제든지 도와드리겠습니다.\n"
            f"다음과 같은 정보를 요청해주세요:\n"
            f"• 보안 업데이트 분석\n"
            f"• 취약점 영향도 평가\n"
            f"• 패치 적용 방안\n"
            f"• 보안 자동화 방안"
        )
    except Exception as e:
        logger.error(f"Error processing mention: {str(e)}")
        logger.error(f"Message text: {message_text}")
        say("처리 중 오류가 발생했습니다. 다시 시도해주세요.")

